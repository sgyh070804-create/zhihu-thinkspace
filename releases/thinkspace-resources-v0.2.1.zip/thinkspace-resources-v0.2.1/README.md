# ThinkSpace 前端与刘看山素材包 0.2.1

packages/debate-room 是冷灰蓝讨论室与运行资源。assets/kanshan 包含已确认模型的可编辑 Blender 原件、高精度 GLB、参考、源码及实际渲染。docs/debate-room 是界面与验证说明。

在 packages/debate-room 中运行 python -m http.server 8780 --bind 127.0.0.1，打开 http://127.0.0.1:8780/index.html 。测试：npm --prefix packages/debate-room test（Node 20+，无需 npm install）。

manifest.json 列出包内文件 SHA-256。角色气泡白底黑字，用户气泡黑底白字。此包仍为前端示例，不连接真实 AI 或 OAuth。
